konsole  -e ./bin/command &
konsole  -e ./src/motor_x &
konsole  -e ./src/motor_z &
konsole  -e ./src/arp_a1 &
konsole  -e ./bin/inspection &